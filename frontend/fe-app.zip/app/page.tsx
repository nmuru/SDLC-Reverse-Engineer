"use client";

import { FormEvent, useState } from "react";

type Phase = {
  id: string;
  label: string;
  shortLabel: string;
};

const phases: Phase[] = [
  { id: "business-purpose", label: "Business Purpose", shortLabel: "Purpose" },
  { id: "features", label: "Features", shortLabel: "Features" },
  { id: "requirements", label: "Requirements", shortLabel: "Requirements" },
  { id: "architecture", label: "Technology Architecture", shortLabel: "Architecture" },
  { id: "high-level-design", label: "High-Level Design", shortLabel: "HLD" },
  { id: "low-level-design", label: "Low-Level Design", shortLabel: "LLD" },
  { id: "implementation", label: "Implementation Detail", shortLabel: "Implementation" },
  { id: "testing", label: "Testing Harness", shortLabel: "Testing" },
  { id: "future", label: "Future Directions", shortLabel: "Future" },
];

const mockContent: Record<string, { title: string; intro: string; items: { title: string; body: string }[] }> = {
  "business-purpose": {
    title: "Business Purpose",
    intro:
      "This is placeholder content for the first SDLC stage. The production agent will infer the business purpose from repository evidence.",
    items: [
      {
        title: "Purpose statement",
        body:
          "IPSUM FACTO: The application appears to solve a defined user or business problem by combining a web interface, application services, persistent data, and domain-specific workflows.",
      },
      {
        title: "Evidence",
        body:
          "IPSUM FACTO: README files, UI routes, package dependencies, configuration, database schemas, and major application modules will be used as evidence.",
      },
      {
        title: "Confidence",
        body: "IPSUM FACTO: Medium confidence. This is dummy data and is not derived from the submitted repository.",
      },
    ],
  },
  features: {
    title: "Major Features",
    intro: "Placeholder feature reconstruction derived from the hypothetical business purpose.",
    items: [
      { title: "User-facing workflow", body: "IPSUM FACTO: Users can access the primary business workflow through a web interface." },
      { title: "Data management", body: "IPSUM FACTO: The system captures, transforms, and persists domain information." },
      { title: "Recommendations or automation", body: "IPSUM FACTO: The application provides intelligent or rules-based assistance for the core workflow." },
      { title: "Reporting and visibility", body: "IPSUM FACTO: Users can inspect outcomes, status, and important information through the UI." },
    ],
  },
  requirements: {
    title: "Major Requirements",
    intro: "Placeholder requirements that would normally be reconstructed from features, tests, routes, UI behavior, and repository evidence.",
    items: [
      { title: "REQ-01 — Core workflow", body: "IPSUM FACTO: The system shall allow a user to initiate and complete the primary business workflow." },
      { title: "REQ-02 — Data persistence", body: "IPSUM FACTO: The system shall persist information required to resume or inspect completed workflows." },
      { title: "REQ-03 — User feedback", body: "IPSUM FACTO: The system shall communicate processing state, success, and failure to the user." },
      { title: "REQ-04 — External integration", body: "IPSUM FACTO: The system shall integrate with required external services where applicable." },
    ],
  },
  architecture: {
    title: "Technology Architecture",
    intro: "Placeholder architecture view. The real agent will infer the architecture from source structure, dependencies, deployment files, APIs, and data flows.",
    items: [
      { title: "Presentation layer", body: "IPSUM FACTO: Browser-based UI implemented as a client-side web application." },
      { title: "Application/API layer", body: "IPSUM FACTO: Backend services expose APIs and coordinate domain operations." },
      { title: "Data layer", body: "IPSUM FACTO: Persistent storage maintains application state and domain entities." },
      { title: "External services", body: "IPSUM FACTO: Third-party APIs or AI services may support specialized capabilities." },
    ],
  },
  "high-level-design": {
    title: "High-Level Design",
    intro: "Placeholder component-level design showing how the major architectural pieces interact.",
    items: [
      { title: "UI → API", body: "IPSUM FACTO: The frontend communicates with backend endpoints over HTTP." },
      { title: "API → Domain services", body: "IPSUM FACTO: Request handlers delegate business operations to domain/application services." },
      { title: "Services → Persistence", body: "IPSUM FACTO: Domain operations read and write persistent entities through a data-access layer." },
      { title: "Services → External systems", body: "IPSUM FACTO: External integrations are isolated behind service boundaries." },
    ],
  },
  "low-level-design": {
    title: "Low-Level Design",
    intro: "Placeholder module inventory. The real output will map concrete repository modules to their responsibilities.",
    items: [
      { title: "Module A — Request handling", body: "IPSUM FACTO: Receives external requests, validates inputs, and returns responses." },
      { title: "Module B — Domain logic", body: "IPSUM FACTO: Contains the core business rules and workflow orchestration." },
      { title: "Module C — Data access", body: "IPSUM FACTO: Encapsulates database queries and persistence operations." },
      { title: "Module D — Integration", body: "IPSUM FACTO: Handles communication with external APIs or services." },
    ],
  },
  implementation: {
    title: "Implementation Detail",
    intro: "Placeholder implementation notes. This stage will explain how the repository actually implements the inferred design.",
    items: [
      { title: "Application startup", body: "IPSUM FACTO: Identify the executable entry point, initialization sequence, configuration, and dependency setup." },
      { title: "Request lifecycle", body: "IPSUM FACTO: Trace a representative request from UI/API entry through business logic to persistence and response." },
      { title: "Configuration", body: "IPSUM FACTO: Identify environment variables, secrets, feature flags, and deployment-specific settings." },
      { title: "How to run", body: "IPSUM FACTO: Reconstruct installation, local development, build, and deployment instructions from the repository." },
    ],
  },
  testing: {
    title: "Testing Harness",
    intro: "Placeholder assessment of the repository's testing strategy and gaps.",
    items: [
      { title: "Existing tests", body: "IPSUM FACTO: Identify unit, integration, end-to-end, API, and UI tests present in the repository." },
      { title: "Requirement coverage", body: "IPSUM FACTO: Map important requirements to existing tests and identify uncovered behavior." },
      { title: "Test execution", body: "IPSUM FACTO: Reconstruct the commands and environment needed to execute the existing test suite." },
      { title: "Recommended additions", body: "IPSUM FACTO: Prioritize tests for critical workflows, failure paths, integrations, and regression risks." },
    ],
  },
  future: {
    title: "Future Directions, Limitations & Ideas",
    intro: "Placeholder forward-looking assessment based on the reconstructed system.",
    items: [
      { title: "Current limitations", body: "IPSUM FACTO: Identify architectural, functional, operational, security, testing, and maintainability limitations." },
      { title: "Potential improvements", body: "IPSUM FACTO: Suggest improvements grounded in observed implementation rather than generic best practices." },
      { title: "Scalability", body: "IPSUM FACTO: Identify likely bottlenecks and opportunities for scaling the application." },
      { title: "Future directions", body: "IPSUM FACTO: Suggest credible next capabilities based on the existing product and architecture." },
    ],
  },
};

export default function Home() {
  const [repoUrl, setRepoUrl] = useState("");
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [analysisStarted, setAnalysisStarted] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [activePhase, setActivePhase] = useState("business-purpose");
  const [completedPhases, setCompletedPhases] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  async function analyze(event: FormEvent) {
    event.preventDefault();

    setLoading(true);
    setAnalysisStarted(true);
    setAnalysisComplete(false);
    setCompletedPhases([]);
    setActivePhase("business-purpose");

    // Prototype only:
    // Simulate the sequential SDLC pipeline without calling FastAPI/Ollama.
    for (const phase of phases) {
      await new Promise((resolve) => setTimeout(resolve, 350));
      setCompletedPhases((current) => [...current, phase.id]);
    }

    setAnalysisComplete(true);
    setLoading(false);
  }

  const activeContent = mockContent[activePhase];

  return (
    <div className="app-shell">
      <header className="topbar">
        <div>
          <div className="brand">ReverseEngineer-SDLC</div>
          <div className="tagline">Repository → Software Engineering Dossier</div>
        </div>
        {analysisStarted && repoUrl && (
          <div className="repo-pill" title={repoUrl}>
            {repoUrl.replace(/^https?:\/\//, "")}
          </div>
        )}
      </header>

      {!analysisStarted ? (
        <main className="landing">
          <div className="landing-card">
            <div className="eyebrow">AI SOFTWARE REVERSE ENGINEERING</div>
            <h1>Turn a GitHub repository into an SDLC dossier.</h1>
            <p className="landing-copy">
              Submit a repository URL and progressively reconstruct its business purpose,
              features, requirements, architecture, design, implementation, testing strategy,
              and future directions.
            </p>

            <form onSubmit={analyze} className="repo-form">
              <input
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
                placeholder="https://github.com/owner/repository"
                type="url"
                required
                aria-label="GitHub repository URL"
              />
              <button type="submit" disabled={loading}>
                {loading ? "Reverse engineering..." : "Reverse engineer"}
              </button>
            </form>

            <div className="landing-note">
              Prototype mode: the SDLC tabs currently contain dummy content.
            </div>
          </div>
        </main>
      ) : (
        <div className="workspace">
          <aside className="sidebar">
            <div className="sidebar-heading">SDLC Dossier</div>
            <div className="progress-label">
              {analysisComplete ? "Analysis complete" : "Reverse engineering..."}
            </div>

            <nav className="phase-nav" aria-label="SDLC phases">
              {phases.map((phase, index) => {
                const complete = completedPhases.includes(phase.id);
                const available = complete || analysisComplete;

                return (
                  <button
                    key={phase.id}
                    className={`phase-tab ${activePhase === phase.id ? "active" : ""} ${
                      !available ? "locked" : ""
                    }`}
                    onClick={() => available && setActivePhase(phase.id)}
                    disabled={!available}
                  >
                    <span className="phase-number">{String(index + 1).padStart(2, "0")}</span>
                    <span className="phase-name">{phase.label}</span>
                    <span className={`phase-status ${complete ? "done" : ""}`}>
                      {complete ? "✓" : "•"}
                    </span>
                  </button>
                );
              })}
            </nav>

            <button
              className="new-analysis"
              onClick={() => {
                setAnalysisStarted(false);
                setAnalysisComplete(false);
                setCompletedPhases([]);
                setRepoUrl("");
                setActivePhase("business-purpose");
              }}
            >
              + New repository
            </button>
          </aside>

          <main className="content">
            {!analysisComplete ? (
              <section className="progress-screen">
                <div className="spinner" />
                <div>
                  <div className="eyebrow">ANALYSIS IN PROGRESS</div>
                  <h1>Reverse engineering the repository</h1>
                  <p>
                    The dossier is being constructed sequentially. Each completed phase becomes
                    available in the navigation.
                  </p>
                </div>
              </section>
            ) : (
              <>
                <section className="completion-banner">
                  <div>
                    <div className="eyebrow">REVERSE ENGINEERING COMPLETE</div>
                    <h1>Your software dossier is ready.</h1>
                    <p>
                      Visit the individual SDLC tabs on the left to explore the reconstructed
                      system.
                    </p>
                  </div>
                  <div className="completion-mark">✓</div>
                </section>

                <section className="dossier-content">
                  <div className="eyebrow">STAGE {String(phases.findIndex((p) => p.id === activePhase) + 1).padStart(2, "0")}</div>
                  <h2>{activeContent.title}</h2>
                  <p className="section-intro">{activeContent.intro}</p>

                  <div className="evidence-grid">
                    {activeContent.items.map((item) => (
                      <article className="evidence-card" key={item.title}>
                        <h3>{item.title}</h3>
                        <p>{item.body}</p>
                      </article>
                    ))}
                  </div>
                </section>
              </>
            )}
          </main>
        </div>
      )}
    </div>
  );
}
